COLOR DASH — FREE INSTALLABLE APP STARTER

This package upgrades the tested Color Dash Achievements game into a Progressive Web App (PWA).
It includes the original game, app manifest, home-screen icons, and offline caching.

IMPORTANT: This ZIP is the app website files, not a Google Play / Apple App Store upload file.
To install it on phones, publish these files to an HTTPS website (GitHub Pages is one free option).

NEXT STEPS (no coding needed):
1. Keep this ZIP as your new app package.
2. Sign in to GitHub or create a free account.
3. Create a PUBLIC repository named color-dash.
4. Upload the files inside this ZIP (upload the files/folders themselves, not the ZIP as a single file). index.html must be at the top level.
5. In the repository, open Settings → Pages. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for GitHub Pages to publish the site. Your address will look like https://YOUR-USERNAME.github.io/color-dash/.
7. Open that HTTPS address on your phone. On Android Chrome, use the menu → Install app or Add to Home screen. On iPhone, open in Safari → Share → Add to Home Screen.

The exact GitHub address depends on your account name. Do not guess it before the site is published.

Offline play: the game files are cached after the first successful visit, but the first visit needs internet. Scores, coins, skins and achievements are saved on that device/browser only; they are not synced between players.
